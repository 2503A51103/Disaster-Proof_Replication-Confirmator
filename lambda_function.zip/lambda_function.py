import json
import os
import boto3
from datetime import datetime, timezone

s3 = boto3.client('s3')
SOURCE_BUCKET = os.environ.get('SOURCE_BUCKET', 'disaster-source-product-13')
DEST_BUCKET = os.environ.get('DEST_BUCKET', 'disaster-dest-product-13')
OBJECT_KEY = os.environ.get('OBJECT_KEY', 'test.txt')


def lambda_handler(event, context):
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
    }
    try:
        src_meta = s3.head_object(Bucket=SOURCE_BUCKET, Key=OBJECT_KEY)
        rep_status = src_meta.get('ReplicationStatus', 'COMPLETED')
        dest_s3 = boto3.client('s3', region_name='us-west-2')
        dest_s3.head_object(Bucket=DEST_BUCKET, Key=OBJECT_KEY)

        status_tier = 'GREEN' if rep_status == 'COMPLETED' else ('YELLOW' if rep_status == 'PENDING' else 'RED')
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'status': status_tier,
                'replicationStatus': rep_status,
                'sourceBucket': SOURCE_BUCKET,
                'destinationBucket': DEST_BUCKET,
                'objectKey': OBJECT_KEY,
                'checkedAt': datetime.now(timezone.utc).isoformat()
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'status': 'RED', 'error': str(e)})
        }
